from flask import Flask
from flask import request
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
import uuid
import time
import os, subprocess
from redis_operate import redis_db
app = Flask(__name__)

CORS(app, supports_credentials=True)
# username_token = {}

# DATABASE = 'test.sqlite'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////Users/miaozhang/PycharmProjects/flaskProject/db.sqlite3'
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# db = SQLAlchemy(app)

# class Event(db.Model):
#     __tablename__ = 'event'
#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     image = db.Column(db.Text)
#     create_time = db.Column(db.DateTime, server_default=db.text('CURRENT_TIMESTAMP'))
#     result = db.Column(db.Text)

# with app.app_context():
#     db.create_all()

@app.route('/login', methods=['POST'])
def login(): # 用户登录请求
    username = request.json.get('username')
    password = request.json.get('password')
    # print(username, password)
    # 生成token
    token = str(uuid.uuid1()) 
    # username_token[username] = token
  
    # 验证登录
    if 'zhang' == username and '1013' ==password:
        # token保存至redis
        redis_db.handle_redis_token(username, token)
        return {
            'code': 0,
            'msg': 'success',
            'data': {
                 'token': token,
                 'username': username
            }
        }
    return {
        'code': 4001,
        'msg': 'fail'
    }
# 退出登录
@app.route('/logout', methods=['POST'])
def logout():
    # 获取token
    token = request.headers.get('token')
    username = request.headers.get('username')
    # if username and token:
    #     redis_token = redis_db.handle_redis_token(username)
    #     if redis_token:
    #         if redis_token == token:
    return {
            'code': 0,
            'msg': 'success'
        }

# 接收前端代码，保存至文件并执行
@app.route('/recvpy', methods=['POST'])
def recvCode():
    # 获取请求头中的token
    token = request.headers.get('token')
    username = request.headers.get('username')
    print(username)
    # flag = False
    # print('username_token:', username_token)
    # 根据用户名从redis中获取token
    redis_token = redis_db.handle_redis_token(username)
    # print("redis_token: ", redis_token)
    # for key, value in username_token.items():
    #     if value == token:
    #         flag = True
    #         break
    if redis_token:
        # token 有效
        if redis_token == token:
            # 获取Python代码
            '''
            import argparse
            if __name__ == "__main__":
                parser = argparse.ArgumentParser(description="annotated data set for aligned")
                parser.add_argument('--a', type=int)
                parser.add_argument('--b', type=int)
                args = parser.parse_args()
                a = args.a
                b = args.b
                print('a + b = %d' % (a + b)) 
            '''
            python_code = request.json.get('code')
            cmd = request.json.get('cmd') # 在命令行需要执行的命令，如 ( python test.py )或 ( ./test.sh )
            filepath = request.json.get('filePath') # 代码保存需要的文件路径
            if filepath[-2:] == 'sh': # 如果是shell脚本文件，需要添加可执行权限
                os.system('chmod +x ' + filepath) 
            # print(request.json)
            # 将代码写入到*filepath*中
            with open(filepath, 'w') as f:
                f.write(python_code)
            command = cmd
            # 执行对应命令
            ret = subprocess.run(
                command, shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                encoding="utf-8", 
                # timeout=1
            )
            # ret.returncode == 0 表示脚本执行成功
            if ret.returncode == 0:
                print("success:",ret)
                return {
                    'code': 0,
                    'msg': ret.stdout
                }
            else:
                print("error:",ret)
                return {
                    'code': 4001,
                    'msg': ret.stderr
                }
        # token失效
        else:
            return {
                'code': 4002,
                'msg': 'Token无效'
            }
    else:
        return {
            'code': 4002,
            'msg': 'Token无效'
        }



if __name__ == '__main__':
    app.run( host='0.0.0.0', debug=True)

